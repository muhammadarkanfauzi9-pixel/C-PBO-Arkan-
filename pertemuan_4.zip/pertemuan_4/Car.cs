using System;

namespace pertemuan_4
{
    class Car : Vehicle  //mewarisi class vehicle
    {
        public string modelName = "Mustang"; //atribut khusus untuk class car
    }
}