using System;

namespace pertemuan_4
{
    class Vehicle
    {
        public string brand = "Ford";//field atau variabel dari class vehicle
        public void honk()
        { 
            Console.WriteLine("Tuut, tuut!");
        }//method honk
    }
}